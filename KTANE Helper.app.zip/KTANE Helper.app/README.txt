---------------------------------
      KTANE Helper (v1.8.4)
  Developed by Marin Taverniers
---------------------------------

This application helps the expert in defusing bombs
in the "Keep Talking and Nobody Explodes" game.


---------------------
 SYSTEM REQUIREMENTS
---------------------
- OS : Windows, Linux, or Mac OS 10.9 (or higher)
- Minimum screen resolution : 1024*720 (1920*1080 recommended)
- Minimum JAVA Runtime Environment : 1.8.0

---------------------------------------
 IMPORTANT NOTE TO RUN THE APPLICATION
---------------------------------------
You will maybe need to authorize the execution of this application by your Operating System, 
because I'm an independent developer not recognized by Microsoft and Apple.

------------------------------------
 LATEST VERSION - HELP TO TRANSLATE
------------------------------------
Github repository : https://github.com/MarinTaverniers/KTANE-Helper

----------------------------------
 BUG REPORTING - FEATURE REQUESTS
----------------------------------
Steam thread : http://steamcommunity.com/app/341800/discussions/0/357284131795715187/

---------
 LICENSE
---------
Please read the "LICENSE.txt" file.


-----------------------------------
Copyright (c) 2017 Marin Taverniers
-----------------------------------
